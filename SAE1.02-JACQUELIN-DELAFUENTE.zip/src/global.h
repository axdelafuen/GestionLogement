/**
 *\file global.h
 *\brief fichier header qui contient les fonctions et variables du programme C afin de le compiler
 *\author JACQUELIN Bastien / DE LA FUENTE Axel
 *\date 08 janvier 2022
  */
void global();

void actualisationLogement();

